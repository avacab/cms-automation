<?php
/**
 * CMS Automation API Client
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class CMS_Automation_API_Client {
    
    private $api_url;
    private $api_key;
    private $site_id;
    
    public function __construct() {
        $this->api_url = get_option('cms_automation_api_url', 'https://cms-automation-api.vercel.app');
        $this->api_key = get_option('cms_automation_api_key', '');
        $this->site_id = get_option('cms_automation_site_id', '');
    }
    
    /**
     * Test API connection
     */
    public function test_connection() {
        $response = $this->make_request('GET', '/api/v1/health');
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            return array(
                'success' => true,
                'message' => __('Connection successful', 'cms-automation-bridge')
            );
        } else {
            return array(
                'success' => false,
                'message' => sprintf(__('HTTP %d error', 'cms-automation-bridge'), $status_code)
            );
        }
    }
    
    /**
     * Create content in CMS
     */
    public function create_content($content_data) {
        $response = $this->make_request('POST', '/api/v1/content', $content_data);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code === 200 || $status_code === 201) {
            return array(
                'success' => true,
                'data' => $data
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['message']) ? $data['message'] : __('Unknown error', 'cms-automation-bridge')
            );
        }
    }
    
    /**
     * Update content in CMS
     */
    public function update_content($cms_id, $content_data) {
        $response = $this->make_request('PUT', "/api/v1/content/{$cms_id}", $content_data);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code === 200) {
            return array(
                'success' => true,
                'data' => $data
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['message']) ? $data['message'] : __('Unknown error', 'cms-automation-bridge')
            );
        }
    }
    
    /**
     * Delete content from CMS
     */
    public function delete_content($cms_id) {
        $response = $this->make_request('DELETE', "/api/v1/content/{$cms_id}");
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200 || $status_code === 204) {
            return array(
                'success' => true,
                'message' => __('Content deleted successfully', 'cms-automation-bridge')
            );
        } else {
            return array(
                'success' => false,
                'message' => __('Failed to delete content', 'cms-automation-bridge')
            );
        }
    }
    
    /**
     * Generate AI content
     */
    public function generate_ai_content($prompt, $options = array()) {
        $data = array(
            'type' => 'complete',
            'input' => array(
                'prompt' => $prompt
            ),
            'options' => array_merge(array(
                'maxTokens' => 2000,
                'temperature' => 0.7,
                'targetLength' => 500
            ), $options)
        );
        
        $response = $this->make_request('POST', '/api/v1/ai/generate', $data);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code === 200 && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']['message']) ? $data['error']['message'] : __('Failed to generate content', 'cms-automation-bridge')
            );
        }
    }
    
    /**
     * Get writing suggestions
     */
    public function get_writing_suggestions($content, $context = array()) {
        $data = array(
            'content' => $content,
            'context' => $context
        );
        
        $response = $this->make_request('POST', '/api/v1/ai/suggestions', $data);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code === 200 && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']['message']) ? $data['error']['message'] : __('Failed to get suggestions', 'cms-automation-bridge')
            );
        }
    }
    
    /**
     * Adapt content to different formats
     */
    public function adapt_content($content, $target_format, $constraints = array()) {
        $data = array(
            'content' => $content,
            'targetFormat' => $target_format,
            'customConstraints' => $constraints
        );
        
        $response = $this->make_request('POST', '/api/v1/ai/adapt', $data);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code === 200 && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']['message']) ? $data['error']['message'] : __('Failed to adapt content', 'cms-automation-bridge')
            );
        }
    }
    
    /**
     * Get available content formats
     */
    public function get_content_formats() {
        $response = $this->make_request('GET', '/api/v1/ai/adapt/formats');
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code === 200 && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => __('Failed to get content formats', 'cms-automation-bridge')
            );
        }
    }
    
    /**
     * Make HTTP request to CMS API
     */
    private function make_request($method, $endpoint, $data = null) {
        $url = rtrim($this->api_url, '/') . $endpoint;
        
        $args = array(
            'method' => $method,
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json',
                'User-Agent' => 'WordPress CMS Automation Bridge/' . CMS_AUTOMATION_VERSION
            )
        );
        
        // Add API key if available
        if (!empty($this->api_key)) {
            $args['headers']['Authorization'] = 'Bearer ' . $this->api_key;
        }
        
        // Add site ID if available
        if (!empty($this->site_id)) {
            $args['headers']['X-Site-ID'] = $this->site_id;
        }
        
        // Add request body for POST/PUT requests
        if ($data !== null && ($method === 'POST' || $method === 'PUT')) {
            $args['body'] = json_encode($data);
        }
        
        // Add WordPress and plugin info
        $args['headers']['X-WordPress-Version'] = get_bloginfo('version');
        $args['headers']['X-Plugin-Version'] = CMS_AUTOMATION_VERSION;
        $args['headers']['X-Site-URL'] = get_site_url();
        
        return wp_remote_request($url, $args);
    }
    
    /**
     * Log API request/response for debugging
     */
    private function log_request($url, $args, $response) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('CMS Automation API Request: ' . $url);
            error_log('CMS Automation API Args: ' . print_r($args, true));
            error_log('CMS Automation API Response: ' . print_r($response, true));
        }
    }
}