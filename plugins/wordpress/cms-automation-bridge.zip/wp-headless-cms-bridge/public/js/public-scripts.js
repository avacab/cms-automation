/**
 * Public JavaScript for WP Headless CMS Bridge
 *
 * @package WP_Headless_CMS_Bridge
 * @since   1.0.0
 */

(function($) {
    'use strict';

    // Add any public-facing JavaScript here if needed

})(jQuery);