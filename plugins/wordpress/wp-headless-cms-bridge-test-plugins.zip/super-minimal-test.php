<?php
/**
 * Plugin Name: Super Minimal Test
 * Version: 1.0.0
 * Description: Absolutely minimal test plugin.
 */

// Prevent direct access
defined('ABSPATH') or die('No script kiddies please!');

// That's it - just the header